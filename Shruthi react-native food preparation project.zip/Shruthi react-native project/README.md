
## Get Started

install dev dependencies

use `npm install` or `yarn install`

## Then

Run The app

use `npm start` or `yarn start`

Runs your app in development mode.

Install expo go from playstore on your phone. It will reload if you save edits to your files, and you will see build errors and logs in the terminal.

`npm run ios` or `yarn run ios`

`npm start` / `yarn start`, but also attempts to open your app in the iOS Simulator if you're on a Mac and have it installed.

`npm run android` or `yarn run android`

Like `npm start` / `yarn start`, but also attempts to open your app on a connected Android device or emulator. 

when ur downloading check the version, if this is one version please update

# generate node_modules and .expo , i cannot upload because file size is large
